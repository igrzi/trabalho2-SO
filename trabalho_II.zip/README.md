# Execução

### Compilação
```
gcc -o codigo codigo.c
```

### Execução
```
./codigo
```